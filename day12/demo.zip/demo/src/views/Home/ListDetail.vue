<template>
  <div>
    <Grid :border="false" :column-num="1">
        <GridItem>
        <van-image
            :src="listDetail.image"
        />
        <p>{{listDetail.name}}</p>
        <p>{{listDetail.price}}</p>
        </GridItem>
    </Grid>
  </div>
</template>

<script>
import { Grid, GridItem,Image } from 'vant';
import axios from '@/request/request'
export default {
    name:'ListDetail',
    components:{
        Grid,
        GridItem,
        'van-image':Image,
    },
    data(){
        return{
            listDetail:{

            }
        }
    },
    mounted(){
       axios.get('/api/list').then(res=>{
         this.listDetail = res.data.list.filter(item => item.id === this.$route.params.id)[0]
       })
    }

}
</script>

<style>

</style>