<template>
    <div>购物页</div>
</template>

<script>
export default {

}
</script>

<style>

</style>