<template>
  <div class="home">
    <NavBar title="主页" class="header"/>
    <!-- 路由出口 -->
    <div class="content">
      <router-view></router-view>
    </div>
    <Tabbar v-model="active">
      <TabbarItem icon="home-o" @click="handleBar">列表</TabbarItem>
      <TabbarItem icon="friends-o" @click="handleBar">购物</TabbarItem>
      <TabbarItem icon="setting-o" @click="handleBar">我的</TabbarItem>
    </Tabbar>
  </div>
</template>

<script>
import { NavBar,Tabbar,TabbarItem } from 'vant';

export default {
  components:{
    NavBar,
    Tabbar,
    TabbarItem,
  },
  data(){
    return {
      active:0,
      routerList:['/home/list','/home/shop','/home/my']
    }
  },
  methods:{
    handleBar(){
      this.$route.path === this.routerList[this.active]? '' : this.$router.push(this.routerList[this.active])
    }
  },
}
</script>

<style lang="scss" scoped>
  .home{
    min-height: 100vh;
    .header{
      height: 40px;
      position: sticky;
      top: 0;
      left: 0;
    }
    display: flex;
    justify-content: space-between;
    flex-direction:column;
    .content{
      flex: 1;
      overflow: auto;
    }
    .van-tabbar{
      position: sticky;
      bottom: 0;
      left: 0;
    }
  }
</style>