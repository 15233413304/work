<template>
  <div class="home-list">
    <Grid :border="false" :column-num="2">
    <GridItem v-for="item in list" :key="item.id" @click="handleItem(item.id)">
      <van-image
        :src="item.image"
      />
      <p>{{item.name}}</p>
      <p>{{item.price}}</p>
    </GridItem>
  </Grid>
  </div>
</template>

<script>
import { Grid, GridItem,Image } from 'vant';
import axios from '@/request/request';
export default {
  components:{
    Grid,
    GridItem,
    'van-image':Image,
  },
  data(){
    return {
      list: []
    }
  },
  methods:{
    handleItem(id){
      // this.$router.push({name:'ListDetail',query:{...opt}})
      this.$router.push(`/home/detail/${id}`)
      // this.$router.push({name:'ListDetail',params:{...opt}})

    }
  },
  mounted(){
    axios.get('/api/list').then(res=>{
      this.list = res.data.list
    })
  }
}
</script>

<style>

</style>