<template>
  <div>个人页</div>
</template>

<script>
export default {

}
</script>

<style>

</style>