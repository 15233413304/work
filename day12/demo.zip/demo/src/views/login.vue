<template>
  <div class="container">
    <NavBar title="登陆页面"/>
    <Form @submit="onSubmit">
      <Field
        v-model="form.username"
        name="用户名"
        label="用户名"
        placeholder="用户名"
        :rules="[{ required: true, message: '请填写用户名' }]"/>
      <Field
        v-model="form.password"
        type="password"
        name="密码"
        label="密码"
        placeholder="密码"
        :rules="[{ required: true, message: '请填写密码' }]"
      />
      <div style="margin: 16px;">
        <Button round block type="info" native-type="submit">提交</Button>
      </div>
    </Form>
  </div>
</template>

<script>
  import { NavBar,Form,Field,Button } from 'vant';
  export default {
    components:{
      NavBar,
      Form,
      Field,
      Button,
    },
    data(){
      return {
        form:{
          username:'',
          password:'',
        }
      }
    },
    methods:{
      onSubmit(val){
        console.log(val)
        // 通过路由的path进行跳转
        this.$router.push('/home')
        // 也可以通过路由的name属性进行跳转
        // this.$router.push({name:'Home'})
      }
    }
  }
</script>

<style>

</style>