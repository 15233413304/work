import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

const routes = [
  {
    path:'/',
    component: ()=>import('../views/index.vue'),
    // 重定向 当访问当前的path时会将路由地址重定向到其他的指定的path
    redirect:'/login',
    children:[
      {
        path:'/home',
        // name: 'Home',
        component: () => import ('../views/Home/Home.vue'),
        redirect:'/home/list',
        children:[
          {
            path:'list',
            component: () => import('../views/Home/HomeList.vue'),
          },
          {
            path:'my',
            component: () => import('../views/Home/HomeMy.vue'),
          },
          {
            path:'shop',
            component: () => import('../views/Home/HomeShop.vue'),
          },
          {
            path:'detail/:id',
            name: 'ListDetail',
            component: () => import('../views/Home/ListDetail.vue'),
          },
        ]
      },
    ]
  },
  {
    path:'/login',
    component: () => import ('../views/login.vue')
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
