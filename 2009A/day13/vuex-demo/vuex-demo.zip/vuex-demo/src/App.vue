<template>
  <div id="app">
    <router-view />
    <h1>{{ $store.state.count }}</h1>
  </div>
</template>

<style lang="stylus">

</style>
