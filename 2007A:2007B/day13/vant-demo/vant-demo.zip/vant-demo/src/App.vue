<template>
  <div>
    <!-- 根路由（0级）出口 -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style>
*{
  margin: 0;
  padding: 0;
}
html,body,#app{
  width: 100%;
  height: 100%;
}
</style>
