<template>
  <div>
    我的资料
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>