<template>
  <div>
    <van-grid :column-num="2" v-if="list.length">
      <van-grid-item v-for="item in list" :key="item.id" @click="handleToDetail(item)">
        <van-image :src="item.img" />
        <p>{{item.name}}</p>
        <p class="price">${{item.price}}</p>
      </van-grid-item>
    </van-grid>
  </div>
</template>

<script>
import getList from '@/mixins/getList'

export default {
  data(){
    return {
      list:[]
    }
  },
  mixins:[getList],
  created(){
    // 调tab1接口 this.$route获取到路由的path
    // console.log(this.$route)
    this.getList(this.$route.path)
    // axios.get('/api/list',{params:{url: this.$route.path}}).then(res=>{
    //   // console.log(res)
    //   this.list = res.data
    // })
  },
  methods:{
    handleToDetail(item){
      console.log(item)

      // 路由传参有两种方式 query params

      // query
      this.$router.push({
        path:'/detail',
        query:{id:item.id,tab:3}
      })
    }


  }
}
</script>

<style>

</style>