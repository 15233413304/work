<template>
  <div>
    <van-grid :column-num="2" v-if="list.length">
      <van-grid-item v-for="item in list" :key="item.id" @click="handleToDetail(item)">
        <van-image :src="item.img" />
        <p>{{item.name}}</p>
        <p class="price">¥{{item.price}}</p>
      </van-grid-item>
    </van-grid>
  </div>
</template>

<script>
// 引入minxins混入
import getList from '@/mixins/getList'

export default {
  data(){
    return {
      list:[]
    }
  },
  // 注册mixins 注册后就可以使用mixins里的任何方法
  mixins:[getList],
  created(){
    // 调tab1接口 this.$route获取到路由的path
    // console.log(this.$route)
    this.getList(this.$route.path)
    // axios.get('/api/list',{params:{url: this.$route.path}}).then(res=>{
    //   // console.log(res)
    //   this.list = res.data
    // })
  },
  methods:{
    handleToDetail(item){
      console.log(item)

      // 路由传参有两种方式 query params
      this.$router.push({
        path:'/detail',
        // 通过query 传递一个id 和一个tab切换标识
        query:{id:item.id,tab:2}
      })
    }


  }
}
</script>

<style>

</style>