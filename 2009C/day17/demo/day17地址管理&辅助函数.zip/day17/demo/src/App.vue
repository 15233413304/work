<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="stylus">
*
  margin 0
  padding 0
html,body,#app
  height 100%
  width 100%
</style>
