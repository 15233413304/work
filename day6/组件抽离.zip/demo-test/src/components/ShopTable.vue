<template>
  <div class="container-content">
    <table border="1" width="800" cellspacing="0" cellpading="0" bordercolor="#000">
        <!-- 全选框 -->
        <!-- table标题 -->
        <th>
        <input type="checkbox" @change="handleCheckAll" v-model="checkAll">
        全选
        <input type="checkbox" @change="handleOther">
        反选
        </th>
        <th v-for="(item,index) in nav" :key="index">
        {{item}}
        </th>
        <!-- table主体 -->
        <tr v-for="(item,index) in shop.length" :key="index+'only'">
        <!-- 单选 -->
        <td> <input type="checkbox" v-model="shop[index].isCheck" @change="handleCheckItem"></td>
        <!-- 商品名称 -->
        <td>{{shop[index].shopName}}</td>
        <!-- 价格 -->
        <td>{{shop[index].price}}</td>
        <!-- 数量 -->
        <td>
            <button @click="handleToJian(index)">-</button>
            {{shop[index].num}}
            <button @click="handleToJia(index)">+</button>
        </td>
        <!-- 总价 -->
        <td>{{ itemPrice(shop[index].price,shop[index].num)}}</td>
        <!-- 操作 -->
        <td>
            <button @click="handleToDel(index)">删除</button>
        </td>
        </tr>
        <!-- 总计 -->
        <td>总计：</td><td colspan="5">{{allCheckPrice}}</td>
    </table>
  </div>
</template>

<script>
export default {
  props: ['nav','shop'],
  data(){
    return {
      checkAll: false
    }
  },
  mounted(){
    console.log(this.nav,this.shop)
  },
  computed:{
    //总计价格
    allCheckPrice(){
      // 筛选出选中的商品
      let newList = this.shop.filter(item => item.isCheck)
      // 统计商品数量的变量
      let num = 0
      newList.forEach(item =>{
        num += this.itemPrice(item.price,item.num)
      })
      return num
    }
  },
  methods:{
    handleCheckAll(){
      this.shop.forEach(item=>{
        item.isCheck = this.checkAll
      })
    },
    handleOther(){
      this.shop.forEach(item=>{
        item.isCheck = !item.isCheck
      })
    },
    handleCheckItem(){
      this.checkAll = this.shop.every(item => item.isCheck)
    },
    // 每一行总价
    itemPrice(a,b){
      return a * b
    },
    // 减少商品
    handleToJian(index){
      // 子传父 => 像父组件通知一个自定义事件
      // this.$emit() 第一个参数是自定义事件名(随便写，只要父组件接受和emit发出的一致就ok) 第二个参数是我们要传过去的变量(数据)
      this.$emit('cur',index)
    },
    // 增加商品
    handleToJia(index){
      this.$emit('add',index)
    },
    // 删除商品
    handleToDel(index){
      this.$emit('del',index)
    }
    
  }
}
</script>

<style>

</style>