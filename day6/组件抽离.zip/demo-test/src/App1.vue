<template>
  <div id="app">
    <div class="container">
      <div class="container-search">
        <input type="text" v-model="inputValue">
        <button @click="handleSearch">搜索</button>
      </div>
      <div class="content" v-if="searchList.length">
        <div v-for="(item,index) in searchList" :key="index">
          {{item}}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return {
      inputValue: '',
      list:['张三','李四','王五','赵六','老六'],
      searchList:[]
    }
  },
  methods:{
    handleSearch(){
      this.searchList = this.list.filter(item => item.includes(this.inputValue))
    }
  }
}
</script>

<style lang="scss">

</style>
