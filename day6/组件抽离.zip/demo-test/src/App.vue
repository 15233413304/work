<template>
  <div id="app">
    <div class="container">
      <!-- 标题 -->
      <h3 class="container-title">购物车</h3>
      <!-- 内容 -->
      <!-- 3.使用组件 -->
      <ShopTable v-if="shopList.length" :nav="navList" :shop="shopList" @cur="handleJian" @add="handleJia" @del="handleDel"></ShopTable>
    </div>
  </div>
</template>

<script>
import axios from './axios/index'
// 1.引入组件
import ShopTable from './components/ShopTable.vue'

export default {
  components:{
    // 2.注册组件
    ShopTable
  },
  data(){
    return {
      navList:['名称','价格','数量','总价','操作'],
      shopList:[],
      checkAll:false,
    }
  },
  computed:{
    // 总计数量
    // allCheckPrice(){
    //   // 筛选出选中的商品
    //   let newList = this.shopList.filter(item => item.isCheck)
    //   // 统计商品数量的变量
    //   let num = 0
    //   newList.forEach(item =>{
    //     num += item.num
    //   })
    //   return num
    // }
    //总计价格
    // allCheckPrice(){
    //   // 筛选出选中的商品
    //   let newList = this.shopList.filter(item => item.isCheck)
    //   // 统计商品数量的变量
    //   let num = 0
    //   newList.forEach(item =>{
    //     num += this.itemPrice(item.price,item.num)
    //   })
    //   return num
    // }
  },
  mounted(){
    axios.get('/api/list').then(res=>{
      // console.log(res)
      this.shopList = res
    })
  },
  methods:{
    //点击全选
    // handleCheckAll(){
    //   this.shopList.forEach(item=>{
    //     item.isCheck = this.checkAll
    //   })
    // },
    //反选
    // handleOther(){
    //   this.shopList.forEach(item=>{
    //     item.isCheck = !item.isCheck
    //   })
    // },
    // 点击单选
    // handleCheckItem(){
    //   this.checkAll = this.shopList.every(item => item.isCheck)
    // },
    // 点击减号
    handleJian(index){
      if(this.shopList[index].num !==1 ){
        this.shopList[index].num --
      }
    },
    // 点击加号
    handleJia(index){
      this.shopList[index].num ++
    },
    // 每一行的总价
    // itemPrice(a,b){
    //   return a * b
    // },
    // 删除
    handleDel(index){
      this.shopList.splice(index,1)
    }
  }
}
</script>
<style lang="scss">
.container{
  width: 800px;
  height: 500px;
  margin: auto;
  background: #eee;
  &-title{
    text-align: center;
    margin: 5px 0;
  }
}
</style>
