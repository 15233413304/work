const { defineConfig } = require("@vue/cli-service");
// 引入mock
const Mock = require('mockjs')
// 模拟数据
const data = Mock.mock({
  "list|10":[
    {
      shopName:'@ctitle(2,4)',
      "price|1-100": 0,
      num:1,
      isCheck: false,
    }
  ]
})
module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave: false,
  devServer:{
    host:'localhost',
    open: true,
    onBeforeSetupMiddleware({app}){
      app.get('/api/list',(req,res)=>{
        res.send(data.list)
      })
    }
  }
});
