<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {

}
</script>

<style>
*{
  margin: 0;
  padding: 0;
}
body,html,#app{
  width: 100%;
  height: 100%;
}
</style>
